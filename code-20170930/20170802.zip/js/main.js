$(document).ready(function(){
  var mq = window.matchMedia( "(min-width: 35em)" );

// var webDesignDetail = document.getElementById("webDesignDetail");
// var webDesignTitle = document.getElementById("webDesignTitle");
// var webDesignIcon = document.getElementById("webDesignIcon");
// var col1 = document.getElementById("col-1");
// //not being used 2010605
// // var showDetail = function()
// // {
// //   if (webDesignDetail.style.display == "none"){
// //     webDesignDetail.style.display = "block";
// //     webDesignTitle.style.display = "none";
// //     webDesignIcon.style.display = "none";
// //   } else {
// //     webDesignDetail.style.display = "none";
// //     webDesignTitle.style.display = "flex";
// //     webDesignIcon.style.display = "flex";
// //   };
// // };
// var hideDetail = function()
// {
//   if (webDesignDetail.style.display == "flex"){
//     webDesignDetail.style.display = "none";
//     webDesignTitle.style.display = "flex";
//     webDesignIcon.style.display = "flex";
//   } else  {
//     webDesignDetail.style.display = "flex";
//     webDesignTitle.style.display = "none";
//     webDesignIcon.style.display = "none";
//   };
// };
// col1.addEventListener("mouseenter", hideDetail, false);
// col1.addEventListener("mouseleave", hideDetail, false);

// $("#webDesignDetail").mouseover();
// $("#webDesignTitle","#webDesignTitle").mouseover(hide());
// $("#col-1").click(
//        function(){$("#wedDesignIcon").show();}//, //shows when hovering over
//       //  function(){$("#webDesignTitle").hide();} //Hides when hovering finished
// );

// var hideIcon = function()
// {$("#webDesignIcon").hide();};
if (mq.matches) {}
else {
  $("#col-1").mouseenter(function()
                          {
                          $("#webDesignTitle").hide();
                          $("#webDesignDetail").show();
                          $("#webContentTitle").show();
                          $("#webContentDetail").hide();
                          $("#webDevTitle").show();
                          $("#webDevDetail").hide();
                       });
  $("#col-2").mouseover(function()
                         {
                         $("#webDevTitle").hide();
                         $("#webDevDetail").show();
                         $("#webDesignTitle").show();
                         $("#webDesignDetail").hide();
                         $("#webContentTitle").show();
                         $("#webContentDetail").hide();
                      });
  $("#col-3").mouseover(function()
                       {
                       $("#webContentTitle").hide();
                       $("#webContentDetail").show();
                       $("#webDevTitle").show();
                       $("#webDevDetail").hide();
                       $("#webDesignTitle").show();
                       $("#webDesignDetail").hide();
                    });
}
});
