<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'ss_dbname_7lnkob6oce');

/** MySQL database username */
define('DB_USER', 'CA0IUG5UhlVjq7s');

/** MySQL database password */
define('DB_PASSWORD', 'ptiPci4UqM7Z5Idp');

/** MySQL hostname */
define('DB_HOST', 'amandaworthingtoncom.fatcowmysql.com');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', 'c;R}ZatH)_yYW>G=K+MVq|;ZHIEvXeMRQ?XEHP|-}>$qbOLfaLx{/j}gTX}A<Ta[{PGCm*;oys}V>YR|hz!TfGCutfK?sgau+ZoGx?iJo}G-|]DnZE&pPJcK{j_+A|+S');
define('SECURE_AUTH_KEY', 'Y/aS[$(=$Z[uo(=)@<cVj+$ua?X?i!g-RyB;TBHy|Ize_-JBe*L$AAKjE]?j<}E?J>Z*-X}ESpAw)DuUWgnyCQmGQ(&geK&IXUZQ+-dN|RKGpKSyJoEvAeC>)lLqmb;{');
define('LOGGED_IN_KEY', 'eAEhloW>$F>]Qr|zc-)/iT+J<HiAH|rz/icMpLx{%_!{NERCCT@kBOBF&%<dtMAnRqE-[[)Lqv&^XoOy(KGYynEmP([psiOn}$}eusALHz/YXfusr]KY$DTCN?a*l)=r');
define('NONCE_KEY', 'mXWvJP!H*vs&$/ya@*NV%Esh/penSF?{wQZSR}BzsN&_?s=Xsmsmi$II{YqzK{IUS}u?p@?j/sxsCL(u(va{+aYdCQSI@Xr&XZ&E]dIOhij)}prMzA-<!;z]!m%^F!_N');
define('AUTH_SALT', 'lX=U=pZ<s-ggdv-C$jfBiT[zzvj&O>RaBx?(^?)OfWos>ZOOlw@b@xRngqH-t<$oXc]AzPpC$yl;;dSOVjrsEz@j/wB(Jfd)nX=tWEh=_/oGFDB^X>_gi}z_+{[xoi%T');
define('SECURE_AUTH_SALT', 'ncTaVrUGVX_NiF}gURwbAEUdeAFd*t-W_??Zq&M&oJyxhtbVRbsB_|oun@JMbdMX?&f)eujtu>qdDGvs%b[P-TA&WSdLs/OwV%ZWeqg_{dLG>]VOFwF]?!ul[|pMKQ^?');
define('LOGGED_IN_SALT', '_F_VpNfvwgsBH{)UUXwK-O<]T[Cty@@a*_shA-!&mf&-+Osh*HUkeiLD[CiqngJ_lU}(/_WcpeW($q/q]=LAPhuEV-Y+&+uN@fED/fF/M|]XJwhM*zHFX_s!}!xL!%uw');
define('NONCE_SALT', 'Uw&f]Mnh)X&]vu[O&@Gg?oxI/pIcwJDsm^CUph]oV}R}d$?U(D<n+l_yvKAI_JkNEna@$stWP$pwh;swiwZ<g)EJvMGeGxbcipBaVjOVMgzPz@nAAYDH;Z)R^yqOw(x&');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_ihst_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
